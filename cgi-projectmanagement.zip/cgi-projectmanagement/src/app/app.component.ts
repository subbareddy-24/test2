import { Component, AfterViewInit } from '@angular/core';

@Component({
  selector: 'cgi-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'app';
}
