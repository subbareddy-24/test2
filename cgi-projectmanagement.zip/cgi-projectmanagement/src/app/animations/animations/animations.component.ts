import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cgi-animations',
  templateUrl: './animations.component.html',
  styleUrls: ['./animations.component.scss']
})
export class AnimationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
