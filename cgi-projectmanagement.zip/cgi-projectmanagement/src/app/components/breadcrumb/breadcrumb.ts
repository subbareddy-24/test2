export class Breadcrumb {
    title: string;
    url: any[];
}
