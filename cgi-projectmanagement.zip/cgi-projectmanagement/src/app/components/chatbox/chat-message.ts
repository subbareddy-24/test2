export class ChatMessage {
    message: string;
    userId: string;
    time: string;
}
