import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cgi-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.scss']
})
export class ContactusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
