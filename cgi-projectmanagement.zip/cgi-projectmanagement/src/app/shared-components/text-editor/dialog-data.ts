export interface DialogData {
    action: string;
    editableString: string;
}
